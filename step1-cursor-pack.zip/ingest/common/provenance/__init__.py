# Common provenance helpers (stub)
# TODO: add functions to compute checksums, write lineage.json, timestamping.
