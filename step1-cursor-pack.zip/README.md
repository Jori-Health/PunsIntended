# Step 1 — Ingest & Normalize (Semantic Search X)

**Goal:** Read JSONL notes from `/sources/{A,B,C}`, validate against `note_raw.schema.json`, preserve provenance, then map to a canonical schema (`note_canonical.schema.json`).

## Quickstart
1. Ensure `/sources/A|B|C/*.jsonl` exist (downloaded earlier).
2. Create output dirs: `/data_lake/{raw,staging,standardized,rejected}` at repo root.
3. Use the connector CLIs (A/B/C) to ingest a file or folder.
4. Run normalization to produce canonical JSONL in `/data_lake/standardized`.
5. Check `/data_lake/rejected` for errors + reasons.

## Testing
Place small JSONL samples in `tests/fixtures`. Run `pytest` (or equivalent) to validate ingest/normalize behavior.
